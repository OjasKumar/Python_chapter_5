a = input("Enter First number:\n")
b = input("Enter Second number:\n")
c = input("Enter Third number:\n")
d = input("Enter Fourth number:\n")
e = input("Enter Fifth number:\n")
f = input("Enter Sixth number:\n")
g = input("Enter Seventh number:\n")
h = input("Enter Eight number:\n")

set = {a, b, c, d, e, f, g, h}
print(set)