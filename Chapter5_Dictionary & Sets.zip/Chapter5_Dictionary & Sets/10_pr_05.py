s = {}

print(s)
print(type(s))

#