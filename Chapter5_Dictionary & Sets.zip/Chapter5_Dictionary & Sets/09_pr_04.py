s = set()
s.add(20) # int
s.add(20.0) # floating point
s.add("20") # String

print(s)
print(len(s))

# When it prints, python thinks that (20) which is int, and (20.0) which is floating point are the same.
# So as you know that values are not repeated in sets, it only prints 2 values of 20.