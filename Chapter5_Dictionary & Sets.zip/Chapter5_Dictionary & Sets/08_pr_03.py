a = {18, "18"}
print(a)

# It will print both the set values as (18) is an int and ("18") is a string
