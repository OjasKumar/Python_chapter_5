favLang = {}
a = input("Enter your favourite language Rob: \n")
b = input("Enter your favourite language Dob: \n")
c = input("Enter your favourite language Tom: \n")
d = input("Enter your favourite language Bob: \n")
favLang["Rob"] = a
favLang["Dob"] = b
favLang["Tom"] = c
favLang["Bob"] = d

print(favLang)
print(type(favLang))