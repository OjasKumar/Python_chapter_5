favLang = {}
a = input("Enter your favourite language Rob: \n")
b = input("Enter your favourite language Dob: \n")
c = input("Enter your favourite language Tom: \n")
d = input("Enter your favourite language Bob: \n")
favLang["Rob"] = a
favLang["Dob"] = b
favLang["Tom"] = c
favLang["Bob"] = d

print(favLang)
print(type(favLang))

# If Names of 2 friends are the same, then the latest name won't get printed.